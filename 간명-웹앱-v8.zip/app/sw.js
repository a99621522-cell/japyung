/* 서비스 워커 — 오프라인으로 돌게 한다.
   이 앱은 서버로 아무것도 보내지 않으므로, 한 번 받으면 계속 쓸 수 있어야 한다. */
const 판 = 'ganmyeong-v8';
const 자산 = ['./', './index.html', './engine.bundle.js', './manifest.json',
              './icon-192.png', './icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(판);
    await c.addAll(자산);
    // 접근벽·오류 페이지가 번들 자리에 캐시되는 사고를 막는다.
    //   (비공개 상태에서 설치되면 HTML이 200으로 오는 수가 있다 — 실제로 겪었다)
    const r = await c.match('./engine.bundle.js');
    const 머리 = (await r.clone().text()).trimStart().slice(0, 1);
    if (머리 === '<') { await caches.delete(판); throw new Error('번들이 HTML로 캐시됨 — 설치 취소'); }
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks =>
    Promise.all(ks.filter(k => k !== 판).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(hit => hit || fetch(e.request).then(res => {
      if (res.ok && new URL(e.request.url).origin === location.origin)
        caches.open(판).then(c => c.put(e.request, res.clone()));
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});
